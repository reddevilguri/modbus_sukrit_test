import tkinter as tk
from easymodbus.modbusClient import *
import numbers

#make changes to the function
def modbusconnect():
    # connect to modbus device
    ip=ent_ip.get()
    modbusclient = ModbusClient(ip, 502)
    modbusclient.parity = Parity.even
    modbusclient.unitidentifier = 2
    modbusclient.baudrate = 9600
    modbusclient.stopbits = Stopbits.one
    modbusclient.connect()
    #print(ip)
    if modbusclient.is_connected():
        print("connected")
    else:
        print("not connected")

def readcoil():
 ip = ent_ip.get()
 modbusclient = ModbusClient(ip, 502)
 modbusclient.parity = Parity.even
 modbusclient.unitidentifier = 2
 modbusclient.baudrate = 9600
 modbusclient.stopbits = Stopbits.one
 modbusclient.connect()
 if ent_coilstrtaddr.get() != '':
        int_coilstrtaddr = int(ent_coilstrtaddr.get())
 if ent_coilqty.get() != '':
     int_coilqty = int(ent_coilqty.get())
 coils = modbusclient.read_coils(int_coilstrtaddr, int_coilqty)
 lbl_rcoil["text"]=coils
 print(coils)
 modbusclient.close()

def readinputregister():
 ip = ent_ip.get()
 modbusclient = ModbusClient(ip, 502)
 modbusclient.parity = Parity.even
 modbusclient.unitidentifier = 2
 modbusclient.baudrate = 9600
 modbusclient.stopbits = Stopbits.one
 modbusclient.connect()
 if ent_inputregisterstrtaddr.get() != '':
        int_inputregisterstrtaddr = int(ent_inputregisterstrtaddr.get())
 if ent_inputregisterqty.get() != '':
     int_inputregisterqty = int(ent_inputregisterqty.get())

 inputRegisters = modbusclient.read_inputregisters(int_inputregisterstrtaddr, int_inputregisterqty)
 lbl_rinputregister["text"]=inputRegisters
 print(inputRegisters)
 modbusclient.close()


window = tk.Tk()
window.title("Modbus Test")

#create button to get IP

window.resizable(width=False, height=False)
frm_entry = tk.Frame(master=window)
ent_ip = tk.Entry(master=frm_entry, width=20)
lbl_ip = tk.Label(master=frm_entry, text="Enter IP")

ent_ip.grid(row=0, column=1)
lbl_ip.grid(row=0, column=0)

#btn_test=tk.Button(master=frm_entry,text="test",command=print_var)
#Create the conversion Button and result display Label

btn_submit = tk.Button(
    master=frm_entry,
    text="Connect",
    command=modbusconnect
)

lbl_result = tk.Label(master=frm_entry)

#Read coils
frm_coil=tk.Frame(master=window)
lbl_coil=tk.Label(master=frm_coil, text="Read coil")
lbl_rcoil=tk.Label(master=frm_coil)
lbl_coilstrtaddr=tk.Label(master=frm_coil, text="Give start address")
ent_coilstrtaddr=tk.Entry(master=frm_coil)



lbl_coilqty=tk.Label(master=frm_coil, text="Give quantity")
ent_coilqty=tk.Entry(master=frm_coil)




btn_coil=tk.Button(master=frm_coil,
                            text="Get Coils",
                            command=readcoil)


#Read input register
frm_inputregister=tk.Frame(master=window)
lbl_inputregister=tk.Label(master=frm_inputregister, text="Read input register")
lbl_rinputregister=tk.Label(master=frm_inputregister)
lbl_inputregisterstrtaddr=tk.Label(master=frm_inputregister, text="Give start address")
ent_inputregisterstrtaddr=tk.Entry(master=frm_inputregister)
lbl_inputregisterqty=tk.Label(master=frm_inputregister, text="Give quantity")
ent_inputregisterqty=tk.Entry(master=frm_inputregister)


btn_inputregister=tk.Button(master=frm_inputregister,
                            text="Get Input Register",
                            command=readinputregister)


# Set-up the layout using the .grid() geometry manager
frm_entry.grid(row=0, column=0, padx=10)
btn_submit.grid(row=0, column=2, padx=10)
#btn_test.grid(row=0,column=4,padx=10)
lbl_result.grid(row=0, column=3, padx=10)

frm_coil.grid(row=1, column=0, padx=10)
lbl_coil.grid(row=1, column=1, padx=10)
lbl_coilstrtaddr.grid(row=2, column=0, padx=10)
ent_coilstrtaddr.grid(row=2, column=1, padx=10)
lbl_coilqty.grid(row=2, column=2, padx=10)
ent_coilqty.grid(row=2, column=3, padx=10)
btn_coil.grid(row=2, column=4, padx=10)
lbl_rcoil.grid(row=2, column=5, padx=10)

frm_inputregister.grid(row=3, column=0, padx=10)
lbl_inputregister.grid(row=3, column=1, padx=10)
lbl_inputregisterstrtaddr.grid(row=4, column=0, padx=10)
ent_inputregisterstrtaddr.grid(row=4, column=1, padx=10)
lbl_inputregisterqty.grid(row=4, column=2, padx=10)
ent_inputregisterqty.grid(row=4, column=3, padx=10)
btn_inputregister.grid(row=4, column=4, padx=10)
lbl_rinputregister.grid(row=4, column=5, padx=10)

# Run the application



window.mainloop()
