import tkinter as tk
from easymodbus.modbusClient import ModbusClient

#make changes to the function



def readdiscreteinput():
    discreteInputs = modbusclient.read_discreteinputs(0, 8)
    lbl_rdiscreteinput["text"]= discreteInputs



window = tk.Tk()
window.title("Modbus Test")

#create button to get IP

window.resizable(width=False, height=False)
frm_entry = tk.Frame(master=window)
ent_ip = tk.Entry(master=frm_entry, width=10)
lbl_ip = tk.Label(master=frm_entry, text="Enter IP")

ent_ip.grid(row=0, column=1)
lbl_ip.grid(row=0, column=0)



# Create the conversion Button and result display Label
btn_submit = tk.Button(
    master=frm_entry,
    text="Submit",
    command=ent_ip.get
)

lbl_result = tk.Label(master=frm_entry)

#connect to modbus device
modbusclient = ModbusClient(ent_ip.get, 502)
modbusclient.connect()

#Read discrete inputs
frm_discreteinput=tk.Frame(master=window)
lbl_discreteinput=tk.Label(master=frm_discreteinput, text="Read 8 discrete inputs")
lbl_rdiscreteinput=tk.Label(master=frm_discreteinput)



btn_discreteinput=tk.Button(master=frm_discreteinput,text="Get 8 discrete Input",command=readdiscreteinput)




# Set-up the layout using the .grid() geometry manager
frm_entry.grid(row=0, column=0, padx=10)
btn_submit.grid(row=0, column=2, pady=10)
lbl_result.grid(row=0, column=3, padx=10)

frm_discreteinput.grid(row=1, column=0, padx=10)
lbl_discreteinput.grid(row=1, column=1, padx=10)
btn_discreteinput.grid(row=1, column=2, padx=10)
lbl_rdiscreteinput.grid(row=1, column=3, padx=10)
# Run the application

modbusclient.close()
window.mainloop()
