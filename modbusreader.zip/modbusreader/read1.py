
from easymodbus.modbusClient import ModbusClient
modbusclient = ModbusClient(‘169.254.130.60’, 502)
modbusclient.connect()
inputRegisters = modbusclient.read_inputregisters(0, 2)
print(inputRegisters)
modbusclient.close